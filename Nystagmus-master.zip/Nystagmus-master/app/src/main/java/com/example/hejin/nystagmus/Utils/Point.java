package com.example.hejin.nystagmus.Utils;

import java.io.Serializable;

public class Point implements Serializable {
    private float x;
    private float y;
    public Point(){
        x = 0;
        y = 0;
    }
    public Point(float xData,float yData){
        x = xData;
        y = yData;
    }
    public void setX(float xData){
        x = xData;
    }
    public void setY(float yData){
        y = yData;
    }
    public float getX() {
        return x;
    }
    public float getY() {
        return y;
    }
}