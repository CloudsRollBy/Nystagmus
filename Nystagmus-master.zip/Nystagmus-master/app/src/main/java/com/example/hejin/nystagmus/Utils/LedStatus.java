package com.example.hejin.nystagmus.Utils;

import java.io.Serializable;

public class LedStatus implements Serializable {
    private float time;
    private boolean ledOn;
    public LedStatus(){
        time = 0;
        ledOn = false;
    }

    public LedStatus(float time,boolean ledOn){
        this.time = time;
        this.ledOn = ledOn;
    }


    public float getTime() {
        return time;
    }

    public boolean isLedOn() {
        return ledOn;
    }
}
