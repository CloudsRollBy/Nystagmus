package com.example.hejin.nystagmus.Utils;

import java.io.Serializable;

public class DiagnosticRecord implements Serializable {
    public String diagnosisResult;
    public String lHorizontal;
    public String lVertical;
    public String lMaxPeriod;
    public String lDirection;
    public String rHorizontal;
    public String rVertical;
    public String rMaxPeriod;
    public String rDirection;
    public Point[] horizonalLeft;
    public Point[] horizonalRight;
    public Point[] verticalLeft;
    public Point[] verticalRight;
    public LedStatus[] ledStatuses;
    public float currentTime;
    public float yMaxX;
    public float yMinX;
    public float yMaxY;
    public float yMinY;

    public DiagnosticRecord(String dr,int hl,int hr,int vl,int vr,int numStatus){
        diagnosisResult = dr;
        horizonalLeft = new Point[hl];
        horizonalRight = new Point[hr];
        verticalLeft = new Point[vl];
        verticalRight = new Point[vr];
        ledStatuses = new LedStatus[numStatus];
    }

}
