package com.example.hejin.nystagmus.Utils;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.hejin.nystagmus.R;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Scope extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private SurfaceHolder mHolder;
    private Canvas mCanvas;
    private boolean mIsDrawing;
    private int mWidth;//控件宽度像素值
    private int mHeight;//控件高度像素值
    private int margin;//控件留白的像素值

    private float yMax;//Y轴最大值
    private float yMin;//Y轴最小值
    private int yLableN;//Y轴显示的坐标个数

    //声明为静态成员变量，原因是要保持两个示波器窗口位置一致
    private static float currentTime;//窗口末端对应的的时间
    private static float timeRange;//窗口显示的时间范围
    private static float timeRangeMax = 20;

    private ScaleGestureDetector mScaleGestureDetector;//缩放手势探测器
    private GestureDetector mGestureDetector;//手势探测器
    private static final String TAG = "Gesture";
    private String scopeName;

    public static final int TIME_IN_FRAME = 50;//刷新时间间隔（ms)
    public static float waitTime;

    //如果有手势使波形发生平移
    //声明为静态成员变量，原因是要保持两个示波器窗口位置一致
    private static float moveToTime;   //平移到的位置
    private static boolean isMoving;   //是否平移
    private static int scrollCount;    //停止平移的时间
    private static boolean isScope;    //是否示波器状态

    private List<Point> points1;
    private List<Line> lines1;
    private List<Point> points2;
    private List<Line> lines2;
    private List<LedStatus> ledSta;

    private boolean isDrawLine = false;


    public Scope(Context context){
        super(context);
        initView();
    }
    public Scope(Context context, AttributeSet attrs){
        super(context,attrs);
        initView();
        initScaleGestureDetector();
        initGestureDetector();

        TypedArray array=context.obtainStyledAttributes(attrs, R.styleable.scope);
        scopeName = array.getString(R.styleable.scope_scopeName);
    }
    public Scope(Context context, AttributeSet attrs, int defStyle){
        super(context,attrs,defStyle);
        initView();
        initScaleGestureDetector();
        initGestureDetector();

        TypedArray array=context.obtainStyledAttributes(attrs, R.styleable.scope);
        scopeName = array.getString(R.styleable.scope_scopeName);
    }

    private void initView(){
        mHolder = getHolder();
        mHolder.addCallback(this);
        setFocusable(true);
        setFocusableInTouchMode(true);
        this.setKeepScreenOn(true);
        yMax = .5f;
        yMin = -.5f;
        margin = 40;
        yLableN = 5;
        currentTime = 0;
        timeRange = 6;
        moveToTime = 0;
        points1 = Collections.synchronizedList(new ArrayList<Point>());
        lines1 = Collections.synchronizedList(new ArrayList<Line>());
        points2 = Collections.synchronizedList(new ArrayList<Point>());
        lines2 = Collections.synchronizedList(new ArrayList<Line>());
        ledSta = Collections.synchronizedList(new ArrayList<LedStatus>());
        isMoving = true;
        scrollCount = 0;
        isScope = true;
        waitTime = 1f;

    }

    private void initScaleGestureDetector() {
        mScaleGestureDetector = new ScaleGestureDetector(getContext(), new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {

                //判断对哪个坐标轴进行缩放
                if(detector.getCurrentSpanX() > detector.getCurrentSpanY()){
                    timeRange = timeRange/detector.getScaleFactor();
                    if(timeRange<0.5f){
                        timeRange = 0.5f;
                    }else if(timeRange>timeRangeMax){
                        timeRange = timeRangeMax;
                    }else;
                }else{
                    float pYMax = yMax;
                    float pYMin = yMin;
                    yMax = (pYMax + pYMin)/2 + (pYMax - pYMin)/2f/detector.getScaleFactor();
                    yMin = (pYMax + pYMin)/2 - (pYMax - pYMin)/2f/detector.getScaleFactor();
                }

                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
            }
        });
    }

    private void initGestureDetector(){
        mGestureDetector = new GestureDetector(getContext(),new GestureDetector.SimpleOnGestureListener(){

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if(e1.getPointerCount()==1 && e2.getPointerCount()==1){
                    isMoving = false;
                    scrollCount = (int) (waitTime*1000/TIME_IN_FRAME)*2;

                    float yScale = (mHeight-margin)/(yMax - yMin);//y坐标到像素的转换比例
                    float xScale = (mWidth - 2*margin)/timeRange;

                    if(Math.abs(distanceX)> Math.abs(distanceY)){
                        moveToTime = moveToTime + distanceX/xScale;

                        if(moveToTime >= currentTime){
                            moveToTime = currentTime;
                            isMoving = true;
                            scrollCount = 0;
                        }else if(moveToTime < timeRange){
                            moveToTime = timeRange;
                        }

                    }else{
                        yMax = yMax - distanceY/yScale;
                        yMin = yMin - distanceY/yScale;
                    }
                }

                return super.onScroll(e1, e2, distanceX, distanceY);
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

                Log.d(TAG, "velocityX = " + velocityX);       // 缩放中心y坐标
                Log.d(TAG, "velocityY = " + velocityY);       // 缩放中心y坐标
                return super.onFling(e1, e2, velocityX, velocityY);
            }
        });

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mWidth = measure(widthMeasureSpec);
        mHeight = measure(heightMeasureSpec);
        if(mWidth>3*mHeight){
            timeRangeMax = 40;
        }
        setMeasuredDimension(mWidth,mHeight);
    }

    private int measure(int measureSpec){
        int result = 0;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        if(specMode == MeasureSpec.EXACTLY){
            result = specSize;
        }else {
            result = 200;
            if(specMode == MeasureSpec.AT_MOST){
                result = Math.min(result,specSize);
            }
        }
        return result;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        mIsDrawing = true;
        new Thread(this).start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        mIsDrawing = false;
    }

    //绘制波形的子线程
    @Override
    public void run() {

        while (mIsDrawing) {
            long startTime = System.currentTimeMillis();

            try {
                mCanvas = mHolder.lockCanvas();
                mCanvas.drawColor(Color.WHITE);

                //波形显示的三种状态
                if(isScope && isMoving){
                    //诊断进行状态下，无手势时波形在自动平移
                    drawAll(mCanvas,currentTime);
                    moveToTime = currentTime;
                }else if(isScope && !isMoving){
                    //诊断进行状态下，有手势时波形随手指平移，手指离开后暂停时间1.5s然后继续自动平移
                    drawAll(mCanvas,moveToTime);
                    if(--scrollCount<=0){
                        isMoving = true;
                    }
                }else if(!isScope){
                    //加载诊断记录，不自动平移，仅仅随手指移动显示波形
                    drawAll(mCanvas,moveToTime);
                }
            } catch (Exception e) {
            } finally {
                if (mCanvas != null) {
                    mHolder.unlockCanvasAndPost(mCanvas);
                }
            }

            long endTime = System.currentTimeMillis();
            /**计算出一次更新的毫秒数**/
            int diffTime = (int) (endTime - startTime);
            /**确保每次更新时间为30帧**/
            while (diffTime <= TIME_IN_FRAME) {
                diffTime = (int) (System.currentTimeMillis() - startTime);
                /**线程等待**/
                Thread.yield();
            }
        }
    }

    private void drawAll(Canvas canvas,float time){
        drawYellowRegion(canvas,time);
        drawCurve(canvas,time);
        drawAxis(canvas,time );
    }

    private void drawAxis(Canvas canvas, float timeEnd){
        //canvas.drawColor(Color.WHITE);
        Paint paint = new Paint();
        paint.setColor(0xFF919191);//坐标轴颜色为灰色
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1);
        //绘制方框
        canvas.drawRect(margin,0,mWidth-margin,mHeight-margin,paint);
        //绘制y轴坐标值
        Paint textPaint = new Paint();//字体格式
        textPaint.setColor(Color.BLACK);//设置颜色为黑色
        textPaint.setStrokeWidth(1);//线宽
        textPaint.setTextSize(15);
        DecimalFormat decimalFormat=new DecimalFormat("0.00");//小数显示格式
        float yScale = (mHeight-margin)/(yMax - yMin);//y坐标到像素的转换比例
        float ylabel;
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float textHeight = fm.descent - fm.ascent - 4;
        for(int i=0;i<yLableN+1;i++){
            ylabel = yMin + i*(yMax - yMin)/yLableN;
            canvas.drawText(decimalFormat.format(ylabel),0,mHeight-margin-(ylabel-yMin)*yScale + textHeight,textPaint);
            canvas.drawText(decimalFormat.format(ylabel),mWidth-margin,mHeight-margin-(ylabel-yMin)*yScale + textHeight,textPaint);
        }
        //绘制y = 0对应水平线
        if(yMin<0){
            textPaint.setColor(0xFF226DDD);
            canvas.drawLine(margin,yMax*yScale,mWidth - margin,yMax*yScale,textPaint);
            canvas.drawText("0",margin+textHeight*0.5f,yMax*yScale+textHeight*1.5f,textPaint);
        }

        //绘制x轴坐标
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(17);
        fm = textPaint.getFontMetrics();
        float xScale = (mWidth - 2*margin)/timeRange;
        if(timeEnd<timeRange){
            //绘制初始时0-timeRange坐标轴
            for(int i=0;i<timeRange+1;i++){
                canvas.drawLine(margin + i*xScale,0,margin + i*xScale,mHeight-margin,paint);
                canvas.drawText(Integer.toString(i),margin + i*xScale,mHeight - margin + (fm.descent - fm.ascent-4),textPaint);
            }
        }else {
            //绘制移动中timeEnd-timeRange到timeEnd的坐标轴
            for(int i = (int) Math.ceil(timeEnd - timeRange); i<= Math.floor(timeEnd); i++){
                canvas.drawLine(margin + (i - timeEnd + timeRange)*xScale,0,margin + (i - timeEnd + timeRange)*xScale,mHeight-margin,paint);
                canvas.drawText(Integer.toString(i),margin + (i - timeEnd + timeRange)*xScale,mHeight - margin + (fm.descent - fm.ascent-4) ,textPaint);
            }
        }

        textPaint.setColor(0xFFF73809);// 颜色为红色
        textPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(margin+5,mHeight-margin-25,margin+25,mHeight-margin-5,textPaint);
        textPaint.setColor(0xFF22DD48);// 曲线为绿色
        canvas.drawRect(margin+80,mHeight-margin-25,margin+100,mHeight-margin-5,textPaint);

        textPaint.setTextSize(20);
        textPaint.setColor(Color.BLACK);
        canvas.drawText("左眼",margin+25,mHeight-margin-7,textPaint);
        canvas.drawText("右眼",margin+100,mHeight-margin-7,textPaint);

        //示波器名字
        canvas.drawText(scopeName,mWidth-margin-80,mHeight-margin-5,textPaint);

    }

    private int findIndex(float endTime, List<Point> points){
        //初始状态下（坐标轴发生平移）
        if(endTime<=timeRange){
            return 0;
        }
        //坐标轴发生平移时
        float startTime = endTime - timeRange;
        for(int i = points.size()-1;i>=0;i--){
            if(points.get(i).getX()<startTime){
                return i+1;
            }
        }
        return -1;
    }

    private void drawCurve(Canvas canvas, float timeEnd){
        Point mPoint;
        boolean isFirst = true;
        Paint linePaint = new Paint();
        linePaint.setAntiAlias(true);//抗锯齿效果，使曲线更平滑
        linePaint.setColor(0xFFF73809);// 颜色为红色
        linePaint.setStrokeWidth(2);// 设置画笔粗细
        linePaint.setStyle(Paint.Style.STROKE);

        Path path1 = new Path();

        float xScale = (mWidth - 2*margin)/timeRange;
        float yScale = (mHeight-margin)/(yMax - yMin);//y坐标到像素的转换比例

        //绘制左眼波形图
        int index1 = findIndex(timeEnd,points1);
        float shift =  - timeEnd + timeRange;
        if(index1 == 0){
            shift = 0;
        }
        if(index1>=0){
            for(int i = index1;i<points1.size();i++){
                mPoint = points1.get(i);
                if(mPoint.getX()<=timeEnd){
                    //判断是否是曲线的第一个点
                    if(isFirst){
                        isFirst = false;
                        path1.moveTo(margin + (mPoint.getX() + shift)*xScale,mHeight-margin-(mPoint.getY()-yMin)*yScale);
                    }else{
                        //防止曲线下部越过示波器下边
                        path1.lineTo(margin + (mPoint.getX() + shift)*xScale,mHeight-margin-(mPoint.getY()-yMin)*yScale);
                    }
                }else {
                    break;
                }
            }
        }
        canvas.drawPath(path1,linePaint);

        //绘制右眼波形图
        Path path2 = new Path();
        linePaint.setColor(0xFF22DD48);// 曲线为绿色
        int index2 = findIndex(timeEnd,points2);
        shift =  - timeEnd + timeRange;
        if(index2 == 0){
            shift = 0;
        }
        isFirst = true;
        if(index2>=0){
            for(int i = index2;i<points2.size();i++){
                mPoint = points2.get(i);
                if(mPoint.getX()<=timeEnd){
                    //判断是否是曲线的第一个点
                    if(isFirst){
                        isFirst = false;
                        path2.moveTo(margin + (mPoint.getX() + shift)*xScale,mHeight-margin-(mPoint.getY()-yMin)*yScale);
                    }else{
                        path2.lineTo(margin + (mPoint.getX() + shift)*xScale,mHeight-margin-(mPoint.getY()-yMin)*yScale);
                    }
                }else {
                    break;
                }
            }
        }
        canvas.drawPath(path2,linePaint);



        if(isDrawLine){
            linePaint.setStrokeWidth(3);
            linePaint.setColor(Color.BLUE);//蓝色
            drawLines(canvas,timeEnd,lines1,linePaint);
            linePaint.setColor(Color.BLACK);//黑色
            drawLines(canvas,timeEnd,lines2,linePaint);
        }

        //防止曲线越过下边界
        linePaint.setColor(Color.WHITE);
        linePaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0,mHeight-margin,mWidth,mHeight,linePaint);
        canvas.drawRect(0,0,margin,mHeight,linePaint);
        canvas.drawRect(mWidth-margin,0,mWidth,mHeight,linePaint);
    }

    private void drawLines(Canvas canvas, float timeEnd,List<Line> lines,Paint linePaint){
        float timeBegin;

        float xScale = (mWidth - 2*margin)/timeRange;
        float yScale = (mHeight-margin)/(yMax - yMin);//y坐标到像素的转换比例

        if(timeEnd<=timeRange){
            timeBegin = 0;
        }else{
            timeBegin = timeEnd - timeRange;
        }
        float shift =  - timeBegin;

        Line line;
        for(int i=0;i<lines.size();i++){
            line = lines.get(i);
            if((line.x1>timeBegin&&line.x1<timeEnd)||(line.x2>timeBegin&&line.x2<timeEnd)){
                canvas.drawLine(margin + (line.x1 + shift)*xScale,(yMax-line.y1)*yScale,
                        margin + (line.x2 + shift)*xScale,(yMax-line.y2)*yScale,linePaint);
            }
        }
    }

    private void drawYellowRegion(Canvas canvas, float timeEnd){

        float ledOnTime;
        float ledOffTime;
        float timeBegin;

        float xScale = (mWidth - 2*margin)/timeRange;

        if(timeEnd<=timeRange){
            timeBegin = 0;
        }else{
            timeBegin = timeEnd - timeRange;
        }

        Paint recPaint = new Paint();
        recPaint.setColor(0xFFffff66);//设置画笔颜色为黄色

        for(int i =0;i<ledSta.size();i++){

            if(!ledSta.get(i).isLedOn()){
                continue;
            }
            ledOnTime = ledSta.get(i++).getTime();
            if(i>=ledSta.size()){
                //最后一个状态是开
                if(timeEnd<=timeRange && ledOnTime>=timeBegin && ledOnTime<=timeEnd){
                    canvas.drawRect(margin + (ledOnTime - timeBegin)*xScale,0,margin + currentTime*xScale,mHeight - margin,recPaint);
                }else if(ledOnTime>timeBegin && ledOnTime<timeEnd){
                    canvas.drawRect(margin + (ledOnTime - timeBegin)*xScale,0,mWidth - margin,mHeight - margin,recPaint);
                }else if(ledOnTime<timeBegin){
                    canvas.drawRect(margin,0,mWidth - margin,mHeight - margin,recPaint);
                }
                break;
            }else{
                ledOffTime = ledSta.get(i).getTime();
                if((ledOnTime>=timeBegin && ledOnTime<=timeEnd) || (ledOffTime>=timeBegin && ledOffTime<=timeEnd)){
                    canvas.drawRect(margin + ((ledOnTime - timeBegin)<0?0:ledOnTime - timeBegin)*xScale,0,margin + (ledOffTime>timeEnd?(timeEnd-timeBegin):(ledOffTime - timeBegin))*xScale,mHeight - margin,recPaint);
                }else if(ledOnTime<timeBegin && ledOffTime>timeEnd){
                    canvas.drawRect(margin,0,mWidth - margin,mHeight - margin,recPaint);
                }
            }
        }
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mScaleGestureDetector.onTouchEvent(event);
        mGestureDetector.onTouchEvent(event);
        return true;
    }

    @Override
    public void setOnTouchListener(OnTouchListener l) {
        super.setOnTouchListener(l);
    }

    public void addPoint(float xData, float yData, boolean eye){
        if(!eye){
            points1.add(new Point(xData,yData));
        }else{
            points2.add(new Point(xData,yData));
        }

        if(isScope && isMoving){
            if(yData>yMax-0.3){
                yMax = yData + 0.3f;
            }else if(yData<yMin+0.3){
                yMin = yData - 0.3f;
            }
        }

        if(xData>currentTime){
            currentTime = xData;
        }
    }

    private class Line implements Serializable {

        public float x1;
        public float y1;
        public float x2;
        public float y2;

        public Line(float xData1,float yData1,float xData2,float yData2){
            x1 = xData1;
            y1 = yData1;
            x2 = xData2;
            y2 = yData2;
        }

    }

    public void addLine(float xData1,float yData1,float xData2,float yData2,boolean eye){
        if(!eye){
            lines1.add(new Line(xData1,yData1,xData2,yData2));
        }else{
            lines2.add(new Line(xData1,yData1,xData2,yData2));
        }
    }

    public void addLedStatus(float time,boolean ledOn){
        if(isScope){
            ledSta.add(new LedStatus(time,ledOn));
        }
    }

    public float getCurrentTime(){
        return currentTime;
    }

    public void setCurrentTime(float currentTime) {
        this.currentTime = currentTime;
    }

    public void initScope(){
        initView();
    }

    public List<Point> getPoints1() {
        return points1;
    }

    public List<Point> getPoints2() {
        return points2;
    }

    public List<LedStatus> getLedSta() {
        return ledSta;
    }

    public float getyMax() {
        return yMax;
    }

    public void setyMax(float yMax) {
        this.yMax = yMax;
    }

    public float getyMin() {
        return yMin;
    }

    public void setyMin(float yMin) {
        this.yMin = yMin;
    }

    public void setPoints1(List<Point> points1) {
        this.points1 = points1;
    }

    public void setPoints2(List<Point> points2) {
        this.points2 = points2;
    }

    public void setLedSta(List<LedStatus> ledSta) {
        this.ledSta = ledSta;
    }

    public void setIsScope(boolean isScope){
        this.isScope = isScope;
        moveToTime = currentTime;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public double[] calculateLines(boolean isReCalculate){

        double[] slopes = new double[2];
        Point pStart;
        Point pEnd;
        if(!isReCalculate){
            CalculateSlope cs1 = new CalculateSlope();
            cs1.arrayToLinked(points1);
            cs1.processEye();

            for(Slope slope:cs1.slopeList){
                pStart = points1.get(slope.getStartIndex());
                pEnd = points1.get(slope.getEndIndex());
                addLine(pStart.getX(),pStart.getY(), pEnd.getX(),pEnd.getY(),false);
            }
            CalculateSlope cs2 = new CalculateSlope();
            cs2.arrayToLinked(points2);
            cs2.processEye();
            for(Slope slope:cs2.slopeList){
                pStart = points2.get(slope.getStartIndex());
                pEnd = points2.get(slope.getEndIndex());
                addLine(pStart.getX(),pStart.getY(), pEnd.getX(),pEnd.getY(),true);
            }
            isDrawLine = true;
            slopes[0] = cs1.slopeResult;
            slopes[1] = cs2.slopeResult;
            return slopes;
        }else{
            lines1.clear();
            lines2.clear();
            int start = findIndex(moveToTime,points1);
            CalculateSlope cs1 = new CalculateSlope();
            CalculateSlope cs2 = new CalculateSlope();
            for(int i = start;(i<points1.size())&&((i<points2.size()))&&(points1.get(i).getX()<=moveToTime);i++){
                cs1.addEye(points1.get(i).getY());
                cs2.addEye(points2.get(i).getY());
            }
            cs1.processEye();
            for(Slope slope:cs1.slopeList){
                pStart = points1.get(slope.getStartIndex()+start);
                pEnd = points1.get(slope.getEndIndex()+start);
                addLine(pStart.getX(),pStart.getY(), pEnd.getX(),pEnd.getY(),false);
            }
            cs2.processEye();
            for(Slope slope:cs2.slopeList){
                pStart = points2.get(slope.getStartIndex()+start);
                pEnd = points2.get(slope.getEndIndex()+start);
                addLine(pStart.getX(),pStart.getY(), pEnd.getX(),pEnd.getY(),true);
            }
            isDrawLine = true;

            slopes[0] = cs1.slopeResult;
            slopes[1] = cs2.slopeResult;
            return slopes;
        }
    }

}
